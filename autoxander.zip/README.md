# Automater


# αυτοματ 



pip install llama-cpp-python  

# To load the file.  


pip install llama-cpp-python[cuda]




pip install playwright watchdog


pip install llama-cpp-python --force-reinstall --upgrade --extra-index-url https://jllllll.github.io/llama-cpp-python-cuBLAS-wheels/AVX2


playwright install





